#!/bin/sh
export PYTHONPATH=$PYTHONPATH:"/home/site/wwwroot/env/lib/site-packages"
echo "Updated PYTHONPATH to '$PYTHONPATH'"
GUNICORN_CMD_ARGS="--timeout 600 --access-logfile '-' --error-logfile '-' --chdir=/home/site/wwwroot" gunicorn app:app