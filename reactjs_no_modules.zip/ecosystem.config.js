module.exports = {
  apps: [
    {
     script: "npx serve dist -s"
    }
        ]
};
